import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { JsonLogger } from '../common/json.logger';
import {
  extractHtScore,
  extractTotalShots,
  getStatValue,
  computePressureIndex,
} from '../common/utils/stats.utils';
import { BacktestRun } from '../database/entities/backtest-run.entity';
import { BetResult } from '../database/entities/bet-result.entity';
import { Fixture } from '../database/entities/fixture.entity';
import { FixtureEvent } from '../database/entities/fixture-event.entity';
import { FixtureStatsSnapshot } from '../database/entities/fixture-stats-snapshot.entity';
import {
  resolveOutcome,
  FinalMatchState,
} from '../recommendations/rules/outcome-resolver';
import {
  evaluateRules,
  RuleEvaluationInput,
} from '../recommendations/rules/rules-evaluator';
import { ExecutableQuoteService } from '../odds/executable-quote.service';
import {
  DEFAULT_MAX_QUOTE_AGE_MS,
  quoteTargetForRuleMarket,
} from '../odds/odds.types';
import { applyStakingAndComputeKpis } from './kpis-calculator';
import { BacktestStrategy, DecidedBet } from './backtest.types';

@Injectable()
export class BacktestEngineService {
  constructor(
    @InjectRepository(BacktestRun)
    private readonly runRepo: Repository<BacktestRun>,
    @InjectRepository(BetResult)
    private readonly betRepo: Repository<BetResult>,
    @InjectRepository(Fixture)
    private readonly fixtureRepo: Repository<Fixture>,
    @InjectRepository(FixtureStatsSnapshot)
    private readonly statsRepo: Repository<FixtureStatsSnapshot>,
    @InjectRepository(FixtureEvent)
    private readonly eventRepo: Repository<FixtureEvent>,
    private readonly executableQuoteService: ExecutableQuoteService,
    private readonly logger: JsonLogger,
  ) {}

  async run(
    name: string,
    strategy: BacktestStrategy,
    window?: { start: Date; end: Date },
  ): Promise<BacktestRun> {
    const resolvedWindow = window ?? (await this.defaultWindow());
    const run = await this.runRepo.save(
      this.runRepo.create({
        name,
        strategy: strategy as unknown as Record<string, unknown>,
        windowStart: resolvedWindow.start,
        windowEnd: resolvedWindow.end,
        status: 'RUNNING',
      }),
    );

    try {
      const decided = await this.replay(strategy, resolvedWindow);
      const { staked, kpis } = applyStakingAndComputeKpis(decided, strategy);

      if (staked.length) {
        await this.betRepo.insert(
          staked.map((b) => ({
            runId: run.id,
            fixtureId: b.fixtureId,
            providerFixtureId: b.providerFixtureId,
            marketType: b.marketType,
            selection: b.selection,
            ruleName: b.ruleName,
            teamId: b.teamId,
            isHomeTeam: b.isHomeTeam,
            decisionAt: b.decisionAt,
            elapsedAtDecision: b.elapsedAtDecision,
            oddAtDecision: b.oddAtDecision,
            oddSource: b.oddSource,
            edgePct: b.edgePct,
            confidenceScore: b.confidenceScore,
            stake: b.stake,
            outcome: b.outcome,
            profit: b.profit,
            resolvedAt: b.outcome === 'NO_RESULT' ? null : new Date(),
          })),
        );
      }

      run.status = 'COMPLETED';
      run.kpis = kpis as unknown as Record<string, unknown>;
      run.totalBets = kpis.betCount;
      run.wonBets = kpis.wonBets;
      run.lostBets = kpis.lostBets;
      run.noResultBets = kpis.noResultBets;
      run.completedAt = new Date();
      await this.runRepo.save(run);

      this.logger.log(
        {
          event: 'backtest_completed',
          runId: run.id,
          bets: kpis.betCount,
          hitRate: kpis.hitRate,
          roiPct: kpis.roiPct,
        },
        'BacktestEngineService',
      );
      return run;
    } catch (error) {
      run.status = 'FAILED';
      run.error = String(error).slice(0, 500);
      run.completedAt = new Date();
      await this.runRepo.save(run);
      this.logger.error(
        { event: 'backtest_failed', runId: run.id },
        error instanceof Error ? error.stack : undefined,
        'BacktestEngineService',
      );
      throw error;
    }
  }

  private async defaultWindow(): Promise<{ start: Date; end: Date }> {
    const row = await this.statsRepo
      .createQueryBuilder('s')
      .select('MIN(s.snapshotAt)', 'min')
      .addSelect('MAX(s.snapshotAt)', 'max')
      .getRawOne<{ min: Date | null; max: Date | null }>();
    const now = new Date();
    return {
      start: row?.min ? new Date(row.min) : now,
      end: row?.max ? new Date(row.max) : now,
    };
  }

  /**
   * Rejeu chronologique sans look-ahead : à chaque tick (snapshotAt), la
   * décision ne lit que les tirs connus à ce tick, l'elapsed du tick et une
   * cote disponible au plus tard à T + latence. La résolution, elle, est
   * post-hoc sur l'état FINAL du match (légitime : elle simule le règlement
   * du pari, pas la décision).
   */
  private async replay(
    strategy: BacktestStrategy,
    window: { start: Date; end: Date },
  ): Promise<DecidedBet[]> {
    const snapshots = await this.statsRepo
      .createQueryBuilder('s')
      .where('s.snapshotAt BETWEEN :start AND :end', window)
      .orderBy('s.snapshotAt', 'ASC')
      .getMany();
    if (!snapshots.length) return [];

    const fixtureIds = [...new Set(snapshots.map((s) => s.fixtureId))];
    const fixtures = await this.fixtureRepo.findBy({ id: In(fixtureIds) });
    const fixtureById = new Map(fixtures.map((f) => [f.id, f]));

    const config = strategy.entryRules;
    const latencyMs = strategy.odds.executionLatencyMs;
    const providerFixtureIds = fixtures.map((fixture) =>
      String(fixture.providerFixtureId),
    );
    const quoteCandidates = await this.executableQuoteService.loadCandidates({
      providerFixtureIds,
      receivedFrom: new Date(
        window.start.getTime() - DEFAULT_MAX_QUOTE_AGE_MS,
      ),
      receivedTo: new Date(window.end.getTime() + latencyMs),
    });

    const snapshotsByFixture = new Map<string, FixtureStatsSnapshot[]>();
    for (const snap of snapshots) {
      const list = snapshotsByFixture.get(snap.fixtureId) ?? [];
      list.push(snap);
      snapshotsByFixture.set(snap.fixtureId, list);
    }

    // Buts (minute) pour reconstruire le score courant à chaque tick (LOT 3.4).
    const goals = await this.eventRepo.find({
      where: { fixtureId: In(fixtureIds), eventType: 'Goal' },
      select: ['fixtureId', 'teamId', 'minute'],
    });
    const goalsByFixture = new Map<string, FixtureEvent[]>();
    for (const goal of goals) {
      const list = goalsByFixture.get(goal.fixtureId) ?? [];
      list.push(goal);
      goalsByFixture.set(goal.fixtureId, list);
    }

    const bets: DecidedBet[] = [];

    for (const [fixtureId, fixtureSnaps] of snapshotsByFixture) {
      const fixture = fixtureById.get(fixtureId);
      if (!fixture) continue;
      if (fixture.homeTeamId === null || fixture.awayTeamId === null) continue;

      const finalState = this.buildFinalState(fixture);
      const placedKeys = new Set<string>();
      const fixtureGoals = goalsByFixture.get(fixtureId) ?? [];

      /** Score de chaque équipe aux buts inscrits jusqu'à `elapsed` inclus. */
      const scoreAt = (elapsed: number): { home: number; away: number } => {
        let home = 0;
        let away = 0;
        for (const g of fixtureGoals) {
          if (g.minute === null || g.minute > elapsed) continue;
          if (g.teamId === fixture.homeTeamId) home += 1;
          else if (g.teamId === fixture.awayTeamId) away += 1;
        }
        return { home, away };
      };

      // État courant reconstruit au fil des ticks (un accumulateur par signal, LOT 3)
      const shotsByTeam = new Map<number, number>();
      const onTargetByTeam = new Map<number, number>();
      const pressureByTeam = new Map<number, number>();
      const htShotsByTeam = new Map<number, number>();
      const htOnTargetByTeam = new Map<number, number>();
      const htPressureByTeam = new Map<number, number>();

      let tickAt: Date | null = null;
      let tickElapsed: number | null = null;

      const evaluateTick = () => {
        if (tickAt === null || tickElapsed === null) return;
        const score = scoreAt(tickElapsed);
        const input: RuleEvaluationInput = {
          elapsed: tickElapsed,
          // Convention apifootball du live : tout match en cours est 'LIVE' ;
          // le fenêtrage 1MT/2MT est porté par elapsed dans l'évaluateur.
          statusShort: 'LIVE',
          home: {
            teamId: fixture.homeTeamId!,
            teamName: fixture.homeTeamName ?? 'Équipe',
            totalShots: shotsByTeam.get(fixture.homeTeamId!) ?? null,
            shotsOnTarget: onTargetByTeam.get(fixture.homeTeamId!) ?? null,
            pressureIndex: pressureByTeam.get(fixture.homeTeamId!) ?? null,
          },
          away: {
            teamId: fixture.awayTeamId!,
            teamName: fixture.awayTeamName ?? 'Équipe',
            totalShots: shotsByTeam.get(fixture.awayTeamId!) ?? null,
            shotsOnTarget: onTargetByTeam.get(fixture.awayTeamId!) ?? null,
            pressureIndex: pressureByTeam.get(fixture.awayTeamId!) ?? null,
          },
          htShots: {
            home: htShotsByTeam.get(fixture.homeTeamId!) ?? 0,
            away: htShotsByTeam.get(fixture.awayTeamId!) ?? 0,
          },
          htOnTarget: {
            home: htOnTargetByTeam.get(fixture.homeTeamId!) ?? 0,
            away: htOnTargetByTeam.get(fixture.awayTeamId!) ?? 0,
          },
          htPressure: {
            home: htPressureByTeam.get(fixture.homeTeamId!) ?? 0,
            away: htPressureByTeam.get(fixture.awayTeamId!) ?? 0,
          },
          scoreHome: score.home,
          scoreAway: score.away,
        };

        for (const match of evaluateRules(input, config)) {
          if (!strategy.markets.includes(match.marketType)) continue;
          if (match.edgePct < strategy.minEdgePct) continue;
          if (match.confidenceScore < strategy.minConfidence) continue;

          const key = `${fixtureId}|${match.teamId}|${match.marketType}`;
          if (placedKeys.has(key)) continue;

          const target = quoteTargetForRuleMarket(
            String(fixture.providerFixtureId),
            match.marketType,
            match.isHomeTeam,
          );
          if (!target) continue;

          const decisionQuote = this.executableQuoteService.selectLatest(
            quoteCandidates,
            {
              target,
              at: tickAt!,
              maxQuoteAgeMs: DEFAULT_MAX_QUOTE_AGE_MS,
            },
          );
          if (
            !decisionQuote ||
            decisionQuote.oddValue < match.minAcceptableOdd
          ) {
            continue;
          }

          const executionQuote = this.executableQuoteService.selectLatest(
            quoteCandidates,
            {
              target: {
                ...target,
                providerKey: decisionQuote.providerKey,
                bookmakerKey: decisionQuote.bookmakerKey,
              },
              at: new Date(tickAt!.getTime() + latencyMs),
              maxQuoteAgeMs: DEFAULT_MAX_QUOTE_AGE_MS,
            },
          );
          if (
            !executionQuote ||
            executionQuote.oddValue < match.minAcceptableOdd
          ) {
            continue;
          }
          placedKeys.add(key);

          const outcome = resolveOutcome(
            { marketType: match.marketType, isHomeTeam: match.isHomeTeam },
            finalState,
          );

          bets.push({
            fixtureId,
            providerFixtureId: String(fixture.providerFixtureId),
            marketType: match.marketType,
            selection: match.selection,
            ruleName: match.ruleName,
            teamId: match.teamId,
            isHomeTeam: match.isHomeTeam,
            decisionAt: tickAt!,
            elapsedAtDecision: tickElapsed,
            oddAtDecision: executionQuote.oddValue,
            oddSource: 'ODDS_SNAPSHOT',
            edgePct: match.edgePct,
            confidenceScore: match.confidenceScore,
            outcome: outcome ?? 'NO_RESULT',
          });
        }
      };

      for (const snap of fixtureSnaps) {
        const at = snap.snapshotAt.getTime();
        if (tickAt !== null && at !== tickAt.getTime()) {
          evaluateTick();
        }
        tickAt = snap.snapshotAt;
        if (snap.elapsed !== null) tickElapsed = snap.elapsed;
        if (snap.teamId) {
          const isHt = (snap.elapsed ?? 99) <= 45;
          const shots = extractTotalShots(snap.stats);
          if (shots !== null) {
            shotsByTeam.set(snap.teamId, shots);
            if (isHt) htShotsByTeam.set(snap.teamId, shots);
          }
          const onTarget = getStatValue(snap.stats, [
            'On Target',
            'Shots on Goal',
          ]);
          onTargetByTeam.set(snap.teamId, onTarget);
          if (isHt) htOnTargetByTeam.set(snap.teamId, onTarget);

          const pressure = computePressureIndex(snap.stats);
          pressureByTeam.set(snap.teamId, pressure);
          if (isHt) htPressureByTeam.set(snap.teamId, pressure);
        }
      }
      evaluateTick();
    }

    return bets;
  }

  private buildFinalState(fixture: Fixture): FinalMatchState {
    const raw = fixture.raw as Record<string, unknown> | null;
    return {
      statusShort: fixture.statusShort ?? '',
      scoreHome: fixture.scoreHome,
      scoreAway: fixture.scoreAway,
      htScoreHome: extractHtScore(raw, true),
      htScoreAway: extractHtScore(raw, false),
    };
  }
}
