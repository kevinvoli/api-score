import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { ScheduleModule } from '@nestjs/schedule';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ApiKeyGuard } from './common/guards/api-key.guard';
import { CommonModule } from './common/common.module';
import { RequestLoggingMiddleware } from './common/middleware/request-logging.middleware';
import { TraceIdMiddleware } from './common/middleware/trace-id.middleware';
import { AppConfigModule } from './config/app-config.module';
import { DatabaseModule } from './database/database.module';
import { FixturesModule } from './fixtures/fixtures.module';
import { MatchModule } from './match/match.module';
import { MonitoringModule } from './monitoring/monitoring.module';
import { RecommendationsModule } from './recommendations/recommendations.module';
import { SettingsModule } from './settings/settings.module';
import { MaintenanceModule } from './maintenance/maintenance.module';
import { ArchiveModule } from './archive/archive.module';
import { AnalyticsModule } from './analytics/analytics.module';
import { TeamsModule } from './teams/teams.module';
import { OddsModule } from './odds/odds.module';
import { BacktestModule } from './backtest/backtest.module';
import { AuditModule } from './audit/audit.module';
import { HistoryModule } from './history/history.module';
import { AuthModule } from './auth/auth.module';
import { SessionGuard } from './common/guards/session.guard';
import { RolesGuard } from './common/guards/roles.guard';

@Module({
  imports: [
    ScheduleModule.forRoot(),
    AppConfigModule,
    CommonModule,
    DatabaseModule,
    FixturesModule,
    MatchModule,
    MonitoringModule,
    RecommendationsModule,
    SettingsModule,
    MaintenanceModule,
    ArchiveModule,
    AnalyticsModule,
    TeamsModule,
    OddsModule,
    BacktestModule,
    AuditModule,
    HistoryModule,
    AuthModule,
  ],
  controllers: [AppController],
  providers: [
    AppService,
    { provide: APP_GUARD, useClass: ApiKeyGuard },
    { provide: APP_GUARD, useClass: SessionGuard },
    { provide: APP_GUARD, useClass: RolesGuard },
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(TraceIdMiddleware, RequestLoggingMiddleware).forRoutes('*');
  }
}
