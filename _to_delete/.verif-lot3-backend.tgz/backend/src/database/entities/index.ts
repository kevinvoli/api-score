import { ApiFootballPayload } from './api-football-payload.entity';
import { ApiUsageLog } from './api-usage-log.entity';
import { AppRuntimeState } from './app-runtime-state.entity';
import { BacktestRun } from './backtest-run.entity';
import { BaseRate } from './base-rate.entity';
import { BetRecommendation } from './bet-recommendation.entity';
import { BetResult } from './bet-result.entity';
import { Country } from './country.entity';
import { Fixture } from './fixture.entity';
import { FixtureAnalytics } from './fixture-analytics.entity';
import { FixtureEvent } from './fixture-event.entity';
import { FixtureLineup } from './fixture-lineup.entity';
import { FixturePlayerStatsSnapshot } from './fixture-player-stats-snapshot.entity';
import { FixtureStatsSnapshot } from './fixture-stats-snapshot.entity';
import { League } from './league.entity';
import { LeagueWatchlist } from './league-watchlist.entity';
import { Match } from './match.entity';
import { OddsSnapshot } from './odds-snapshot.entity';
import { SmartCoupon } from './smart-coupon.entity';
import { Standing } from './standing.entity';
import { Team } from './team.entity';
import { AuthUser } from './auth-user.entity';
import { AuthSession } from './auth-session.entity';
import { OperationAuditEvent } from './operation-audit-event.entity';
import { AuthLoginAttempt } from './auth-login-attempt.entity';

export const ALL_ENTITIES = [
  ApiFootballPayload,
  ApiUsageLog,
  AppRuntimeState,
  BacktestRun,
  BaseRate,
  BetRecommendation,
  BetResult,
  Country,
  Fixture,
  FixtureAnalytics,
  FixtureEvent,
  FixtureLineup,
  FixturePlayerStatsSnapshot,
  FixtureStatsSnapshot,
  League,
  LeagueWatchlist,
  Match,
  OddsSnapshot,
  SmartCoupon,
  Standing,
  Team,
  AuthUser,
  AuthSession,
  OperationAuditEvent,
  AuthLoginAttempt,
];
